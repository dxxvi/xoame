package home;

import spark.Spark;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Spark.get("/processes", (request, response) -> {
            response.type("text/html");
            return "<pre>" + execute(new String[] {"tasklist"}) + "</pre>";
        });

        Spark.get("/kill/:process", (request, response) -> {
            response.type("text/html");
            String process = request.params(":process");
            List<String> lines = Arrays.asList(execute(new String[] {"tasklist"}).split("\n"));

            Predicate<String> startsWithEqualSigns = s -> s.startsWith("======");
            ToIntFunction<String> getFirstColumnWidth = s -> {
                int i = s.indexOf(" ");
                return i < 1 ? 0 : i;
            };
            OptionalInt width = lines.stream()
                    .filter(startsWithEqualSigns)
                    .mapToInt(getFirstColumnWidth)
                    .filter(i -> i > 0)
                    .findAny();
            if (width.isPresent()) {
                Function<String, String> getFirstColumn = s -> s.substring(0, Math.min(width.getAsInt(), s.length())).trim();
                Predicate<String> containsProcessToKill = s -> s.contains(process);
                Predicate<String> containsNoSpace = s -> !s.contains(" ");
                Function<String, String> killProcess = s -> {
                    return execute(new String[] {"taskkill", "/F", "/IM", s, "/T"});
                };

                return "<pre>" + lines.stream()
                        .map(getFirstColumn)
                        .filter(containsProcessToKill)
                        .filter(containsNoSpace)
                        .distinct()
                        .map(killProcess)
                        .collect(Collectors.joining("\n\n")) + "</pre>";
            }
            else {
                return "<pre>Unable to find the ======== line from\n" + String.join("\n", lines) + "</pre";
            }
        });
    }

    private static String execute(String[] array) {
//        if (array.length > 2) return String.join(" ", Arrays.asList(array));

        try {
            Process process = Runtime.getRuntime().exec(array);
            BufferedInputStream bis = new BufferedInputStream(process.getInputStream());
            String result = new String(bis.readAllBytes());
            bis.close();
            return result;
        }
        catch (Throwable ioex) {
            return ioex.getMessage();
        }
    }
}
