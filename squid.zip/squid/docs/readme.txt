To contact the maintainer of this package, e-mail on squidnt@acmeconsulting.it.
The latest version and documentation can be found on
http://www.acmeconsulting.it/SquidNT.htm.
